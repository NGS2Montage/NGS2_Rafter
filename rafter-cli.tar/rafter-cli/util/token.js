var jwt = require("jsonwebtoken");
var defer = require("promised-io/promise").defer;

module.exports.decode = function(token){
	var def = new defer();
	try {
		var decoded = jwt.decode(token);
//		console.log("decoded: ", decoded);
		def.resolve(decoded);
	}catch(err){
		return	def.reject(err);
	}
	return def.promise;
}
