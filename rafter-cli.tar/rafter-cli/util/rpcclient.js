var defer = require("promised-io/promise").defer;
var request = require("request");

var idx=0;

module.exports = function(endpoint, token){
		return function(method, params){
			var req = {id: idx++, method: method, params: params,jsonrpc:"2.0"};
			var def = new defer();
			//console.log("Request: ", req);
			//console.log("JSON RPC Endpoint: ", endpoint);
			request.post(	
				endpoint, 
				{
					headers: {
						accept: "application/json",
						"content-type": "application/jsonrequest",
						"authorization": token
					
					},
					body: req,
					json: true
				},
				function(err,response,data){
					//console.log("Got Response: ", data);
					if (err){
						return def.reject(err);
					}
		

					if (response.statusCode != 200){
						return def.reject("Error in Request");
					}

					if (!data){
						return def.reject("Missing Response");
					}

					if (data.error){
						return def.reject(data.error);
					}

					//console.log("Resolving JSON RPC REquest: ", data.result);

					def.resolve(data.result);

				}
			)

			return def.promise;
		}
    }

