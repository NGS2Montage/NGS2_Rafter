var fs = require("fs");
var tilde = require('tilde-expansion');
var defer = require("promised-io/promise").defer;
var when = require("promised-io/promise").when;

var configFile = "~/.rafter/config.json";

var config = {
    "volumeServiceURL": "https://rafter.bi.vt.edu/volumesvc/",
    "jobServiceURL": "https://rafter.bi.vt.edu/jobsvc/",
    "userServiceURL": "https://rafter.bi.vt.edu/usersvc/",
}

var def = new defer();

tilde(configFile, function(configFile){

	fs.exists(configFile, function(exists){
		if (exists){
			fs.readFile(configFile,"utf8", function(err,data){
				if (err){
					throw new Error(err);
				}
				var data = JSON.parse(data);
				//console.log("Config FIle Data: ", data);
				Object.keys(data).forEach(function(key){
					config[key]=data[key];
				});
				
				def.resolve(config);
			});
		}else{
			//console.log("no config file found");
			def.resolve(config);
		}
	});
});


module.exports.get = function(){
	return when(def.promise, function(config){
		return config;
	});

};



